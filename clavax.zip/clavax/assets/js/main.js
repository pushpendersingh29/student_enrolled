(function ($) {
	'use strict';

	jQuery(document).ready(function () {

		$('.slider-content').owlCarousel({
			items: 1,
			nav: false,
			dots: true,
			loop: true,
			autoplay: true
		});

	});


})(jQuery);