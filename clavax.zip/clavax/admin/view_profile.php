<?php
$output = '';
$rec_id = $_POST['id'];
 $conn = mysqli_connect("localhost", "root", "", "db_admission");
 

$sql = "SELECT * FROM student where id=".$rec_id;
$result = mysqli_query($conn, $sql);

 

   while($row = mysqli_fetch_assoc($result)) {
 
$output .= "<div class='row'><div class='col-sm-6'>Id: ".$row["id"]."</div><div class='col-sm-6'>Name ".$row["sname"]."</div></div><div class='row'> <div class='col-sm-6'>Gender: ".$row["gender"]."</div></div><div class='row'>";

 }
echo $output;
 
mysqli_close($conn);
?>