<?php
                     $sname = "";
                    $gname = "";
                    $dob = "";
                    $contact = "";
                    $email = "";
                    $address = "";
                    $state = "";
                    $city = "";
                    $pincode = "";
                    $class = "";
                    $marks = "";
                    $gender = "";
                    
                    $esname = "";
                    $egname = "";
                    $edob = "";
                    $econtact = "";
                    $eemail = "";
                    $eaddress = "";
                    $estate = "";
                    $ecity = "";
                    $epincode = "";
                    $eclass = "";
                    $emarks = "";
                    $egender = "";


    $sql = "select * from student where id = ".$_GET['eid'];
    $table = mysqli_query($cn, $sql);
    $row = mysqli_fetch_assoc($table);
					
	if(isset($_POST['submit']))
	{
	   $sname = $_POST['sname'];
        $gname = $_POST['gname'] ;
        $dob = $_POST['dob'];
        $contact = $_POST['contact'];
        $email = $_POST['email'];
        $address = $_POST['address'];
        $state = $_POST['state'];
        $city = $_POST['city'];
        $pincode = $_POST['pincode'];
        $class = $_POST['class'];
        $marks = $_POST['marks'];
						
	if(isset($_POST['gender']))
                    $gender = $_POST['gender'];
                        
                        $er = 0;
                        
                        if($sname == "")
                        {
                            $er++;
                            $esname = "*Required";
                        }
                        else{
                            $sname = test_input($sname);
                            if(!preg_match("/^[a-zA-Z ]*$/",$sname)){
                            $er++;
                            $esname = "*Only letters and white space allowed";
                        }
                        }

                        if($gname == "")
                        {
                            $er++;
                            $egname = "*Required";
                        }
                        else{
                            $gname = test_input($gname);
                            if(!preg_match("/^[a-zA-Z ]*$/",$gname)){
                            $er++;
                            $egname = "*Only letters and white space allowed";
                        }
                        }

                        if($contact == "")
                        {
                            $er++;
                            $econtact = "*Required";
                        }
                        else{
                            $contact = test_input($contact);
                            if(!preg_match("/^[+0-9]*$/",$contact)){
                            $er++;
                            $econtact = "*Only numbers are allowed";
                            }
                            
                        }

                        if($email == "")
                        {
                            $er++;
                            $eemail = "*Required";
                        }
                        else
                        {
                            $email = test_input($email);
                            if(!filter_var($email, FILTER_VALIDATE_EMAIL))
                            {
                                $er++;
                                $eemail = "*Email format is invalid";
                            }
                            
                        }

                        if($address == "")
                        {
                            $er++;
                            $eaddress = "*Required";
                        }

                        if($class == 0)
                        {
                            $er++;
                            $eclass = "*Required";
                        }

                        if($state == '')
                        {
                            $er++;
                            $estate = "*Required";
                        }
                        if($city == '')
                        {
                            $er++;
                            $ecity = "*Required";
                        }
                        if($pincode == '')
                        {
                            $er++;
                            $epincode = "*Required";
                        }

                         if (empty($gender)) {
                            $er++;
                            $egender = "*Gender is required";
                          } else {
                            $gender = test_input($gender);
                          }

                        // if($pincode == "")
                        // {
                        //  $er++;
                        //  $epincode = "*Required";
      //                   }
      //                   elseif(strlen($pincode) == 6)
      //                   {
      //                       $er++;
      //                       $pincode = "*6 character required";
      //                   }
                            
      //                   else
      //                   {
      //                       $pincode = test_input($pincode);
      //                       if(!preg_match("/^[a-zA-Z+-]*$/",$pincode))
      //                       {
      //                           $er++;
      //                           $pincode = "*Pincode not valid";
      //                       }

      //                   }

                        if($marks == 0)
                        {
                            $er++;
                            $emarks = "*Please enter marks";
                        }
        if($er == 0)
        {
            $sql = "update student set sname = '".strip_tags($sname)."', 
            gname = '".strip_tags($gname)."',
            dob = '".strip_tags($dob)."',
            contact = '".strip_tags($contact)."',
            email = '".strip_tags($email)."',
            address = '".strip_tags($address)."',
            state = '".strip_tags($state)."',
            city = '".strip_tags($city)."',
            pincode = '".strip_tags($pincode)."',
            class = '".strip_tags($class)."',
            marks = ".strip_tags($marks)." ,
            gender = ".strip_tags($gender)." where id = ".$_GET['eid'];
            
            if(mysqli_query($cn, $sql))
            {
                print '<span class = "successMessage">Data update successfully</span>';
                $row['sname'] = "";
                $row['gname'] = "";
                $row['dob'] = "";
                $row['contact'] = "";
                $row['email'] = "";
                $row['address'] = "";
                $row['state'] = "";
                $row['city'] = "";
                $row['pincode'] = "";
                $row['class'] = "";
                $row['marks'] = "";
                $row['gender'] = "";
            }
            else
            {
                print '<span>'.mysqli_error($cn).'</span>';
            }
        }
    }
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>


<div class="form-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h3 id="et">Edit Record of :
                        <?php print $row["sname"]; ?>'s information</h3>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <form action="" method="post">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="left-side-form">
                                        <h5><label for="sname">Student name</label>
                                            <span class="error">
                                                <?php print $esname; ?></span></h5>
                                        <p><input type="text" name="sname" value="<?php print $row['sname']; ?>"></p>

                                        <h5><label for="gname">Gurdian name</label><span class="error">
                                                <?php print $egname; ?></span></h5>
                                        <p><input type="text" name="gname" value="<?php print $row['gname']; ?>"></p>

                                        <h5><label for="dob">Date of Birth</label><span class="error">
                                                <?php print $edob; ?></span></h5>
                                        <p><input type="date" name="dob" class="form-control" value="<?php print $row['dob']; ?>"></p>

                                        <h5><label for="gender">Gender</label></h5>
                                        <p><select name="gender" id="" class="form-control">
                                                <option value="0">Select Gender</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select><span class="error">
                                                <?php print $egender; ?></span></p>

                                        <h5><label for="contact">contact</label><span class="error">
                                                <?php print $econtact; ?></span></h5>
                                        <p><input type="text" name="contact" value="<?php print $row['contact']; ?>"></p>

                                        <h5><label for="email">email</label><span class="error">
                                                <?php print $eemail; ?></span></h5>
                                        <p><input type="text" name="email" value="<?php print $row['email']; ?>"></p>

                                        
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="right-side-form">
                                        <h5><label for="address">address</label><span class="error">
                                                <?php print $eaddress; ?></span></h5>
                                        <p><textarea name="address"><?php print $row['address']; ?></textarea></p>

                                        

                                        <h5><label for="state">State</label><span class="error">
                                                <?php print $estate; ?></span></h5>
                                        <p><input type="text" name="state" value="<?php print $row['state']; ?>"></p>

                                        <h5><label for="city">City</label><span class="error">
                                                <?php print $ecity; ?></span></h5>
                                        <p><input type="text" name="city" value="<?php print $row['city']; ?>"></p>

                                        <h5><label for="pincode">Pincode</label><span class="error">
                                                <?php print $epincode; ?></span></h5>
                                        <p><input type="text" name="pincode" value="<?php print $row['pincode']; ?>"></p>


                                        <h5><label for="class">Class</label></h5>
                                        <p><select name="class" id="">
                                                <option value="0">Select Class</option>
                                                <option value="5th">5th</option>
                                                <option value="6th">6th</option>
                                                <option value="7th">7th</option>
                                                <option value="8th">8th</option>
                                                <option value="9th">9th</option>
                                                <option value="10th">10th</option>
                                            </select><span class="error">
                                                <?php print $eclass; ?></span></p>

                                        <h5><label for="marks">Marks</label><span class="error">
                                                <?php print $emarks; ?></span></h5>

                                        <p><input type="text" name="marks" value="<?php print $row['marks']; ?>"></p>


                                        <p><input type="submit" name="submit" value="Save Change"></p>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
